export default class Event {
  constructor(debug=false) {
    this._debug = debug
  }

  updateTurnState() {

  }

  updateGame() {

  }


}
