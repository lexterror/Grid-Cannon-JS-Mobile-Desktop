import Game from './game.js'

export default class Card {
  get name() {
    return this._name
  }

  get suit() {
    return this._suit
  }

  get faceName() {
    switch (this._name) {
      case Card.Names.JACK:
        return 'J'
      case Card.Names.QUEEN:
        return 'Q'
      case Card.Names.KING:
        return 'K'
      case Card.Names.ACE:
        return 'A'
      case Card.Names.JOKER:
        return 'JOKER'
      default:
        return this.value
    }
  }

  get suitSymbol() {
    switch (this._suit) {
      case Card.Suits.SPADE:
        return '\u2660'
      case Card.Suits.CLUB:
        return '\u2663'
      case Card.Suits.HEART:
        return '\u2665'
      case Card.Suits.DIAMOND:
        return '\u2666'
      default:
        return ''
    }
  }

  get faceText() {
    var str;
    
     if (this._name == "ACE" && this._suit == "CLUB")
    str = "url(png/01c.svg)";
    if (this._name == "ACE" && this._suit == "SPADE")
    str = "url(png/01s.svg)";
    if (this._name == "ACE" && this._suit == "HEART")
    str = "url(png/01h.svg)";
    if (this._name == "ACE" && this._suit == "DIAMOND")   
    str = "url(png/01d.svg)";
    if (this._name == "KING" && this._suit == "CLUB")
    str = "url(png/13c.svg)";
    if (this._name == "KING" && this._suit == "SPADE")
    str = "url(png/13s.svg)";
    if (this._name == "KING" && this._suit == "HEART")
    str = "url(png/13h.svg)";
    if (this._name == "KING" && this._suit == "DIAMOND")   
    str = "url(png/13d.svg)";
    if (this._name == "QUEEN" && this._suit == "CLUB")
    str = "url(png/12c.svg)";
    if (this._name == "QUEEN" && this._suit == "SPADE")
    str = "url(png/12s.svg)";
    if (this._name == "QUEEN" && this._suit == "HEART")
    str = "url(png/12h.svg)";
    if (this._name == "QUEEN" && this._suit == "DIAMOND")   
    str = "url(png/12d.svg)";
    if (this._name == "JACK" && this._suit == "CLUB")
    str = "url(png/11c.svg)";
    if (this._name == "JACK" && this._suit == "SPADE")
    str = "url(png/11s.svg)";
    if (this._name == "JACK" && this._suit == "HEART")
    str = "url(png/11h.svg)";
    if (this._name == "JACK" && this._suit == "DIAMOND")   
    str = "url(png/11d.svg)";
    if (this._name == "TWO" && this._suit == "CLUB")
    str = "url(png/02c.svg)";
    if (this._name == "TWO" && this._suit == "SPADE")
    str = "url(png/02s.svg)";
    if (this._name == "TWO" && this._suit == "HEART")
    str = "url(png/02h.svg)";
    if (this._name == "TWO" && this._suit == "DIAMOND")   
    str = "url(png/02d.svg)";
    if (this._name == "THREE" && this._suit == "CLUB")
    str = "url(png/03c.svg)";
    if (this._name == "THREE" && this._suit == "SPADE")
    str = "url(png/03s.svg)";
    if (this._name == "THREE" && this._suit == "HEART")
    str = "url(png/03h.svg)";
    if (this._name == "THREE" && this._suit == "DIAMOND")   
    str = "url(png/03d.svg)";
    if (this._name == "FOUR" && this._suit == "CLUB")
    str = "url(png/04c.svg)";
    if (this._name == "FOUR" && this._suit == "SPADE")
    str = "url(png/04s.svg)";
    if (this._name == "FOUR" && this._suit == "HEART")
    str = "url(png/04h.svg)";
    if (this._name == "FOUR" && this._suit == "DIAMOND")   
    str = "url(png/04d.svg)";
    if (this._name == "FIVE" && this._suit == "CLUB")
    str = "url(png/05c.svg)";
    if (this._name == "FIVE" && this._suit == "SPADE")
    str = "url(png/05s.svg)";
    if (this._name == "FIVE" && this._suit == "HEART")
    str = "url(png/05h.svg)";
    if (this._name == "FIVE" && this._suit == "DIAMOND")   
    str = "url(png/05d.svg)";
    if (this._name == "SIX" && this._suit == "CLUB")
    str = "url(png/06c.svg)";
    if (this._name == "SIX" && this._suit == "SPADE")
    str = "url(png/06s.svg)";
    if (this._name == "SIX" && this._suit == "HEART")
    str = "url(png/06h.svg)";
    if (this._name == "SIX" && this._suit == "DIAMOND")   
    str = "url(png/06d.svg)";
    if (this._name == "SEVEN" && this._suit == "CLUB")
    str = "url(png/07c.svg)";
    if (this._name == "SEVEN" && this._suit == "SPADE")
    str = "url(png/07s.svg)";
    if (this._name == "SEVEN" && this._suit == "HEART")
    str = "url(png/07h.svg)";
    if (this._name == "SEVEN" && this._suit == "DIAMOND")   
    str = "url(png/07d.svg)";
    if (this._name == "EIGHT" && this._suit == "CLUB")
    str = "url(png/08c.svg)";
    if (this._name == "EIGHT" && this._suit == "SPADE")
    str = "url(png/08s.svg)";
    if (this._name == "EIGHT" && this._suit == "HEART")
    str = "url(png/08h.svg)";
    if (this._name == "EIGHT" && this._suit == "DIAMOND")   
    str = "url(png/08d.svg)";
    if (this._name == "NINE" && this._suit == "CLUB")
    str = "url(png/09c.svg)";
    if (this._name == "NINE" && this._suit == "SPADE")
    str = "url(png/09s.svg)";
    if (this._name == "NINE" && this._suit == "HEART")
    str = "url(png/09h.svg)";
    if (this._name == "NINE" && this._suit == "DIAMOND")   
    str = "url(png/09d.svg)";
    if (this._name == "TEN" && this._suit == "CLUB")
    str = "url(png/10c.svg)";
    if (this._name == "TEN" && this._suit == "SPADE")
    str = "url(png/10s.svg)";
    if (this._name == "TEN" && this._suit == "HEART")
    str = "url(png/10h.svg)";
    if (this._name == "TEN" && this._suit == "DIAMOND")   
    str = "url(png/10d.svg)";
   if (this._name == "JOKER")
    str = "url(png/joker.svg)";
    return str; 
   //return `${this.faceName} ${this.suitSymbol}`
  }

  get gridPosition() {
    return [
      this._gridX,
      this._gridY,
    ]
  }

  set gridPosition([x, y]) {
    this._gridX = x
    this._gridY = y
  }

  get value() {
    const nameToValue = {
      [Card.Names['JOKER']]:  0,
      [Card.Names['ACE']]:    1,
      [Card.Names['TWO']]:    2,
      [Card.Names['THREE']]:  3,
      [Card.Names['FOUR']]:   4,
      [Card.Names['FIVE']]:   5,
      [Card.Names['SIX']]:    6,
      [Card.Names['SEVEN']]:  7,
      [Card.Names['EIGHT']]:  8,
      [Card.Names['NINE']]:   9,
      [Card.Names['TEN']]:    10,
      [Card.Names['JACK']]:   11,
      [Card.Names['QUEEN']]:  12,
      [Card.Names['KING']]:   13,
    }

    return nameToValue[this._name]
  }

  get isSpot() {
    return this.value >= 2 && this.value <= 10
  }

  get isFace() {
    return this.value > 10
  }

  get isJoker() {
    return this.value === 0
  }

  get isAce() {
    return this.value === 1
  }

  get color() {
    switch(this.suit) {
      case Card.Suits.SPADE:
      case Card.Suits.CLUB:
        return 'BLACK'
      case Card.Suits.DIAMOND:
      case Card.Suits.HEART:
        return 'RED'
      default:
        return 'PURPLE'
    }
  }

  static get Names() {
    return {
      JOKER: 'JOKER',
      ACE: 'ACE',
      TWO: 'TWO',
      THREE: 'THREE',
      FOUR: 'FOUR',
      FIVE: 'FIVE',
      SIX: 'SIX',
      SEVEN: 'SEVEN',
      EIGHT: 'EIGHT',
      NINE: 'NINE',
      TEN: 'TEN',
      JACK: 'JACK',
      QUEEN: 'QUEEN',
      KING: 'KING',
    }
  }

  static get Suits() {
    return {
      SPADE: 'SPADE',
      CLUB: 'CLUB',
      HEART: 'HEART',
      DIAMOND: 'DIAMOND',
    }
  }

  constructor(name, suit, gridX, gridY) {
    this._name = name
    this._suit = suit
    this._gridX = gridX
    this._gridY = gridY
    this._killed = null
  }

  kill() {
    if (this.isFace) {
      this._killed = true
    }
  }

  render(cardElement) {
    if (cardElement.classList.contains('hidden')) {
      return
    }

    if (this._killed) {
      cardElement.classList.add('back')
      cardElement.classList.remove('empty')
      cardElement.classList.remove('face')
      cardElement.style.backgroundImage = ''
    //  cardElement.innerHTML = '&nbsp;'
     // cardElement.textContent = ''
     //cardElement.style.color = ''
      return
    }

    cardElement.classList.remove('empty')
   // cardElement.classList.add('face')

    cardElement.style.backgroundImage = this.faceText
   //cardElement.style.color = this.color
  
  }

  /*toString() {
    let name
    if (this._name === Card.Names.JOKER) {
      name = 'JR'
    } else if (this._name === Card.Names.TEN) {
       name = 'T'
    } else {
      name = this.value
    }

     const suit = this.suitSymbol
   
    var str;
    //return `${this.faceName} ${this.suitSymbol}`
    if (name == "ACE" && suit == "CLUB")
    str = "url(png/01c.svg)";
    if (name == "ACE" && suit == "SPADE")
    str = "url(png/01s.svg)";
    if (name == "ACE" && suit == "HEART")
    str = "url(png/01h.svg)";
    if (name == "ACE" && suit == "DIAMOND")   
    str = "url(png/01d.svg)";
    if (name == "KING" && suit == "CLUB")
    str = "url(png/13c.svg)";
    if (name == "KING" && suit == "SPADE")
    str = "url(png/13s.svg)";
    if (name == "KING" && suit == "HEART")
    str = "url(png/13h.svg)";
    if (name == "KING" && suit == "DIAMOND")   
    str = "url(png/13d.svg)";
    if (name == "QUEEN" && suit == "CLUB")
    str = "url(png/12c.svg)";
    if (name == "QUEEN" && suit == "SPADE")
    str = "url(png/12s.svg)";
    if (name == "QUEEN" && suit == "HEART")
    str = "url(png/12h.svg)";
    if (name == "QUEEN" && suit == "DIAMOND")   
    str = "url(png/12d.svg)";
    if (name == "JACK" && suit == "CLUB")
    str = "url(png/11c.svg)";
    if (name == "JACK" && suit == "SPADE")
    str = "url(png/11s.svg)";
    if (name == "JACK" && suit == "HEART")
    str = "url(png/11h.svg)";
    if (name == "JACK" && suit == "DIAMOND")   
    str = "url(png/11d.svg)";
    if (name == "TWO" && suit == "CLUB")
    str = "url(png/02c.svg)";
    if (name == "TWO" && suit == "SPADE")
    str = "url(png/02s.svg)";
    if (name == "TWO" && suit == "HEART")
    str = "url(png/02h.svg)";
    if (name == "TWO" && suit == "DIAMOND")   
    str = "url(png/02d.svg)";
    if (name == "THREE" && suit == "CLUB")
    str = "url(png/03c.svg)";
    if (name == "THREE" && suit == "SPADE")
    str = "url(png/03s.svg)";
    if (name == "THREE" && suit == "HEART")
    str = "url(png/03h.svg)";
    if (name == "THREE" && suit == "DIAMOND")   
    str = "url(png/03d.svg)";
    if (name == "FOUR" && suit == "CLUB")
    str = "url(png/04c.svg)";
    if (name == "FOUR" && suit == "SPADE")
    str = "url(png/04s.svg)";
    if (name == "FOUR" && suit == "HEART")
    str = "url(png/04h.svg)";
    if (name == "FOUR" && suit == "DIAMOND")   
    str = "url(png/04d.svg)";
    if (name == "FIVE" && suit == "CLUB")
    str = "url(png/05c.svg)";
    if (name == "FIVE" && suit == "SPADE")
    str = "url(png/05s.svg)";
    if (name == "FIVE" && suit == "HEART")
    str = "url(png/05h.svg)";
    if (name == "FIVE" && suit == "DIAMOND")   
    str = "url(png/05d.svg)";
    if (name == "SIX" && suit == "CLUB")
    str = "url(png/06c.svg)";
    if (name == "SIX" && suit == "SPADE")
    str = "url(png/06s.svg)";
    if (name == "SIX" && suit == "HEART")
    str = "url(png/06h.svg)";
    if (name == "SIX" && suit == "DIAMOND")   
    str = "url(png/06d.svg)";
    if (name == "SEVEN" && suit == "CLUB")
    str = "url(png/07c.svg)";
    if (name == "SEVEN" && suit == "SPADE")
    str = "url(png/07s.svg)";
    if (name == "SEVEN" && suit == "HEART")
    str = "url(png/07h.svg)";
    if (name == "SEVEN" && suit == "DIAMOND")   
    str = "url(png/07d.svg)";
    if (name == "EIGHT" && suit == "CLUB")
    str = "url(png/08c.svg)";
    if (name == "EIGHT" && suit == "SPADE")
    str = "url(png/08s.svg)";
    if (name == "EIGHT" && suit == "HEART")
    str = "url(png/08h.svg)";
    if (name == "EIGHT" && suit == "DIAMOND")   
    str = "url(png/08d.svg)";
    if (name == "NINE" && suit == "CLUB")
    str = "url(png/09c.svg)";
    if (name == "NINE" && suit == "SPADE")
    str = "url(png/09s.svg)";
    if (name == "NINE" && suit == "HEART")
    str = "url(png/09h.svg)";
    if (name == "NINE" && suit == "DIAMOND")   
    str = "url(png/09d.svg)";
    if (name == "TEN" && suit == "CLUB")
    str = "url(png/10c.svg)";
    if (name == "TEN" && suit == "SPADE")
    str = "url(png/10s.svg)";
    if (name == "TEN" && suit == "HEART")
    str = "url(png/10h.svg)";
    if (name == "TEN" && suit == "DIAMOND")   
    str = "url(png/10d.svg)";
   if (name == "JOKER")
    str = "url(png/joker.svg)";
    //return str; 


    return `${name}${suit}`
  }*/
}
