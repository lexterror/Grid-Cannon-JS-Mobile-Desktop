import Game from './grid-cannon/game.js'

window.game = new Game()
